AI Acts Like Humans
-------------------


A [Pen](https://codepen.io/Bruno-SCHUSTER/pen/jEVmegZ) by [Bruno SCHUSTER](https://codepen.io/Bruno-SCHUSTER) on [CodePen](https://codepen.io).

[License](https://codepen.io/license/pen/jEVmegZ).